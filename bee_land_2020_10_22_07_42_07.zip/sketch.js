let bg, hero;
const horizon = 470;
let bgX = 0, bgY = 0;

function preload(){
  bg = loadImage('bee_land.jpeg');
}

function setup() {
  createCanvas(500, 500);
  hero = new HeroBall();

}

function draw() {
  
  if(bgX < -5000){
    nextLevel()
  }
  
  
  image(bg, bgX, bgY);
  
  
  hero.update();
  hero.display();
  console.log(bgX);
  
}

function mousePressed(){
  hero.burstForward();
  bgX -= 20;
  
}