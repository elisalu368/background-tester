class HeroBall {
  constructor(){
    this.x = 100;
    this.y = 300;
    this.r = 25;
    this.fillColor = [120,90,220];
  }
  
  
  display(){
    fill(this.fillColor);
    ellipse(this.x, this.y, this.r * 2);
  }
  
  burstForward(){
    if(this.x < 300){
       this.x+=60;
    }
   if(this.y - this.r > 30){
      this.y -=30;
   }
   
  }
  
  
  driftBack(){
    this.x -= 0.5;
  }
  
  driftDown(){
    if(this.y + this.r < horizon){
      this.y += 1.5
    }
    
  }
  
  
  update(){
    this.driftBack();
    this.driftDown();
  }
}